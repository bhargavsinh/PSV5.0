/**
 * Pushti Sahitya — Full-page loader
 * Fake progress with short pauses at key %, completes on window.load,
 * holds 3556ms at 100%, then fades 800ms.
 * 25s timeout → /offline.html
 */
(function () {
  'use strict';

  var L = document.getElementById('ps-loader');
  if (!L) return;

  var F = document.getElementById('ps-fill');
  var N = document.getElementById('ps-pct-num');
  var p = 0;
  var done = false;
  var fake = null;
  var t25 = null;
  var pausing = false;

  // Pause points (approx) — hold 500ms then continue
  var pauseAt = [12, 35, 55, 70, 90, 99];
  var paused = {};

  function set(v) {
    p = Math.max(0, Math.min(100, v));
    if (F) F.style.width = p + '%';
    if (N) N.textContent = Math.floor(p);
    L.setAttribute('aria-valuenow', Math.floor(p));
  }

  function maybePause() {
    if (pausing || done) return;
    for (var i = 0; i < pauseAt.length; i++) {
      var target = pauseAt[i];
      if (!paused[target] && p >= target) {
        paused[target] = true;
        pausing = true;
        clearInterval(fake);
        setTimeout(function () {
          pausing = false;
          if (!done) startFake();
        }, 500);
        return;
      }
    }
  }

  function startFake() {
    if (fake) clearInterval(fake);
    fake = setInterval(function () {
      if (done || p >= 90) return;
      set(p + (Math.random() * 6 + 1.2));
      maybePause();
    }, 280);
  }

  startFake();

  t25 = setTimeout(function () {
    if (!done) window.location.href = '/offline.html';
  }, 25000);

  function finish() {
    if (done) return;
    done = true;
    if (fake) clearInterval(fake);
    clearTimeout(t25);
    set(100);

    // Hold 3556ms at 100%, then fade 800ms
    setTimeout(function () {
      L.classList.add('ps-hide');
      setTimeout(function () {
        if (L && L.parentNode) L.parentNode.removeChild(L);
      }, 800);
    }, 3556);
  }

  if (document.readyState === 'complete') finish();
  else window.addEventListener('load', finish);
})();
