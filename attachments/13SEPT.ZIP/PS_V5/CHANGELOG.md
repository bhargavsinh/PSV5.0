# Pushti Sahitya — V5.0 CHANGELOG

## Critical fix: Desktop navigation dropdowns

### Problem
Top-level and nested sub-menus did not open reliably on desktop because:
- `[hidden] { display: none !important }` overrode weak hover rules
- Click handlers and outside-click raced
- Nested flyouts went off-screen / were clipped by `overflow-x: hidden`

### V5.0 solution
- Desktop nav is now **CSS-first**: `:hover`, `:focus-within`, and `.is-open` all show panels with `!important`
- Click toggles `.is-open` on the parent wrapper (`.nav-dropdown` / `.nav-nested`) for touch and keyboard
- Nested menus stack under the parent on mid-width screens (1100–1400px) so they never leave the viewport
- Header/footer badges and service-worker cache set to **V5.0**

### Still true from V4
- Perplexity / preview injections removed
- `__psStore` removed (uses localStorage)
- Aggressive protection.js simplified
- Canonical Grantha data accessors
- Detail page handles duplicate IDs
- Mobile logo sizing fixed
- Content text unchanged

