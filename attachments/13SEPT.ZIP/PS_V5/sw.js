/* Pushti Sahitya V4.0 — Service Worker
   Strategy: HTML network-first / SWR, JSON network-first,
   CSS/JS/images cache-first, no bulk PDF precache.
*/
const CACHE_VERSION = 'pushti-sahitya-v5.2-canonical-nav';
const PRECACHE = [
  './index.html',
  './offline.html',
  './404.html',
  './granthas.html',
  './about.html',
  './shodash-granthas.html',
  './contact.html',
  './components/header.html',
  './components/footer.html',
  './style.css',
  './colors.css',
  './script.js',
  './protection.js',
  './digital-granthapal-v62.js',
  './digital-granthapal-v62.css',
  './data/granthas.json',
  './manifest.webmanifest',
  './favicon.ico',
  './favicon.svg',
  './images/icons/icon-192.png',
  './images/icons/icon-512.png',
  './images/icons/apple-touch-icon.png'
];

self.addEventListener('install', function (event) {
  event.waitUntil(
    caches.open(CACHE_VERSION).then(function (cache) {
      return Promise.all(
        PRECACHE.map(function (u) {
          return cache.add(new Request(u, { cache: 'reload' })).catch(function () { return null; });
        })
      );
    }).then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys.filter(function (k) { return k !== CACHE_VERSION; })
            .map(function (k) { return caches.delete(k); })
      );
    }).then(function () { return self.clients.claim(); })
  );
});

function isJSON(url) {
  return /granthas\.json|nav-map\.json|\.json(\?|$)/i.test(url);
}
function isAsset(url) {
  return /\.(css|js|png|jpg|jpeg|webp|svg|ico|woff2?)(\?|$)/i.test(url);
}
function isHTML(url) {
  return /\.html(\?|$)/i.test(url) || url.endsWith('/') || !/\.[a-z0-9]+(\?|$)/i.test(url);
}

self.addEventListener('fetch', function (event) {
  var req = event.request;
  if (req.method !== 'GET') return;
  var url = req.url;

  // Network-first for JSON
  if (isJSON(url)) {
    event.respondWith(
      fetch(req).then(function (res) {
        if (res && res.ok) {
          var clone = res.clone();
          caches.open(CACHE_VERSION).then(function (c) { c.put(req, clone); });
        }
        return res;
      }).catch(function () {
        return caches.match(req);
      })
    );
    return;
  }

  // Cache-first for static assets
  if (isAsset(url)) {
    event.respondWith(
      caches.match(req).then(function (cached) {
        if (cached) return cached;
        return fetch(req).then(function (res) {
          if (res && res.ok) {
            var clone = res.clone();
            caches.open(CACHE_VERSION).then(function (c) { c.put(req, clone); });
          }
          return res;
        });
      })
    );
    return;
  }

  // Network-first (stale-while-revalidate) for HTML/navigation
  event.respondWith(
    fetch(req).then(function (res) {
      if (res && res.ok) {
        var clone = res.clone();
        caches.open(CACHE_VERSION).then(function (c) { c.put(req, clone); });
      }
      return res;
    }).catch(function () {
      return caches.match(req).then(function (cached) {
        return cached || caches.match('./offline.html');
      });
    })
  );
});

self.addEventListener('message', function (event) {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
