/**
 * Pushti Sahitya V4.0 — Lightweight content guidance
 * No aggressive copy-blocking, no DevTools detection, no keyboard traps.
 * Respects user agency; relies on legal notices + CSP for real protection.
 */
(function () {
  'use strict';
  // Soft image drag prevention only (UX convenience, not security)
  document.addEventListener('dragstart', function (e) {
    if (e.target && e.target.tagName === 'IMG') {
      // Allow if user explicitly wants; mild default
      // e.preventDefault(); // intentionally not forced
    }
  }, { passive: true });
})();
